const guildId = location.pathname.split('/')[2];

async function init() {
  const [userRes, configRes, ticketsRes, appsRes, giveawaysRes, invitesRes] = await Promise.all([
    fetch('/api/user'),
    fetch(`/api/guild/${guildId}/config`),
    fetch(`/api/guild/${guildId}/tickets`),
    fetch(`/api/guild/${guildId}/applications`),
    fetch(`/api/guild/${guildId}/giveaways`),
    fetch(`/api/guild/${guildId}/invites`),
  ]);

  const user = await userRes.json();
  const config = await configRes.json();
  const tickets = await ticketsRes.json();
  const apps = await appsRes.json();
  const giveaways = await giveawaysRes.json();
  const invites = await invitesRes.json();

  // User info
  document.getElementById('userInfo').innerHTML = `
    <img src="https://cdn.discordapp.com/avatars/${user.id}/${user.avatar}.png?size=64" alt="avatar" class="user-avatar">
    <div class="user-details">
      <div class="user-name">${user.username}</div>
      <div class="user-tag">ადმინი</div>
    </div>
  `;

  // Overview stats
  const openTickets = tickets.filter(t => t.status === 'open').length;
  const pendingApps = apps.filter(a => a.status === 'pending').length;
  document.getElementById('overviewStats').innerHTML = `
    <div class="stat-card"><div class="stat-value">${tickets.length}</div><div class="stat-label">🎫 სულ ბილეთები</div></div>
    <div class="stat-card"><div class="stat-value">${openTickets}</div><div class="stat-label">🟢 ღია ბილეთები</div></div>
    <div class="stat-card"><div class="stat-value">${apps.length}</div><div class="stat-label">📝 განაცხადები</div></div>
    <div class="stat-card"><div class="stat-value">${pendingApps}</div><div class="stat-label">⏳ მოლოდინში</div></div>
    <div class="stat-card"><div class="stat-value">${giveaways.length}</div><div class="stat-label">🎉 გათამაშებები</div></div>
  `;

  // Recent tickets
  const recentTickets = tickets.slice(0, 6);
  document.getElementById('recentTickets').innerHTML = recentTickets.length
    ? recentTickets.map(t => `
        <div class="list-item">
          <span>🎫 <@${t.user_id}> — #${t.id}</span>
          <span class="badge ${t.status === 'open' ? 'badge-success' : 'badge-danger'}">${t.status === 'open' ? 'ღია' : 'დახურული'}</span>
        </div>`).join('')
    : '<div class="empty-state"><p>ბილეთები არ არის</p></div>';

  // Recent apps
  const recentApps = apps.slice(0, 6);
  document.getElementById('recentApps').innerHTML = recentApps.length
    ? recentApps.map(a => `
        <div class="list-item">
          <span>📝 ${a.name} — #${a.id}</span>
          <span class="badge ${a.status === 'pending' ? 'badge-warning' : a.status === 'accepted' ? 'badge-success' : 'badge-danger'}">
            ${a.status === 'pending' ? 'განხილვაში' : a.status === 'accepted' ? 'მიღებული' : 'უარყოფილი'}
          </span>
        </div>`).join('')
    : '<div class="empty-state"><p>განაცხადები არ არის</p></div>';

  // Tickets table
  document.getElementById('ticketsTable').innerHTML = tickets.length
    ? tickets.map(t => `
        <tr>
          <td>#${t.id}</td>
          <td><code>${t.user_id}</code></td>
          <td><span class="badge ${t.status === 'open' ? 'badge-success' : 'badge-danger'}">${t.status === 'open' ? 'ღია' : 'დახურული'}</span></td>
          <td>${new Date(t.created_at * 1000).toLocaleString('ka-GE')}</td>
        </tr>`).join('')
    : '<tr><td colspan="4" style="text-align:center;color:var(--text-muted);padding:2rem">ბილეთები არ არის</td></tr>';

  // Giveaways
  document.getElementById('giveawaysList').innerHTML = giveaways.length
    ? giveaways.map(g => `
        <div class="giveaway-card">
          <div class="giveaway-prize">🎉 ${g.prize}</div>
          <div class="giveaway-meta">
            <span>🏆 გამარჯვებლები: ${g.winner_count}</span>
            <span>⏰ სრულდება: <strong>${new Date(g.ends_at * 1000).toLocaleString('ka-GE')}</strong></span>
            <span>ID: #${g.id}</span>
          </div>
        </div>`).join('')
    : '<div class="empty-state"><p>🎉 აქტიური გათამაშება არ არის</p></div>';

  // Invites table
  document.getElementById('invitesTable').innerHTML = invites.length
    ? invites.map((row, i) => {
        const total = row.real_count - row.left_count - row.fake_count + row.bonus;
        const medal = i === 0 ? '🥇' : i === 1 ? '🥈' : i === 2 ? '🥉' : `${i + 1}.`;
        return `<tr>
          <td>${medal}</td>
          <td><code>${row.user_id}</code></td>
          <td><strong>${total}</strong></td>
          <td>${row.real_count}</td>
          <td>${row.left_count}</td>
          <td>${row.bonus}</td>
        </tr>`;
      }).join('')
    : '<tr><td colspan="6" style="text-align:center;color:var(--text-muted);padding:2rem">მოწვევის ჩანაწერი არ არის</td></tr>';

  // Applications
  const statusLabel = s => s === 'pending' ? 'განხილვაში' : s === 'accepted' ? 'მიღებული' : 'უარყოფილი';
  const statusClass = s => s === 'pending' ? 'badge-warning' : s === 'accepted' ? 'badge-success' : 'badge-danger';
  document.getElementById('applicationsList').innerHTML = apps.length
    ? apps.map(a => `
        <div class="app-card">
          <div class="app-card-header">
            <div class="app-name">📝 ${a.name} <span style="font-weight:400;font-size:.8rem;color:var(--text-muted)">#${a.id}</span></div>
            <span class="badge ${statusClass(a.status)}">${statusLabel(a.status)}</span>
          </div>
          <div class="app-field"><div class="app-field-label">მომხმარებელი</div><div class="app-field-value"><code>${a.user_id}</code></div></div>
          <div class="app-field"><div class="app-field-label">ასაკი</div><div class="app-field-value">${a.age}</div></div>
          <div class="app-field"><div class="app-field-label">გამოცდილება</div><div class="app-field-value">${a.experience}</div></div>
          <div class="app-field"><div class="app-field-label">მოტივაცია</div><div class="app-field-value">${a.reason}</div></div>
          ${a.extra ? `<div class="app-field"><div class="app-field-label">დამატებითი</div><div class="app-field-value">${a.extra}</div></div>` : ''}
          <div style="margin-top:.6rem;font-size:.75rem;color:var(--text-muted)">${new Date(a.submitted_at * 1000).toLocaleString('ka-GE')}</div>
        </div>`).join('')
    : '<div class="empty-state"><p>📝 განაცხადები არ არის</p></div>';

  // Settings form
  populateSettings(config);
}

function populateSettings(config) {
  const form = document.getElementById('settingsForm');
  if (!form) return;
  const fields = ['join_channel', 'join_message', 'leave_channel', 'leave_message',
    'auto_role', 'ticket_category', 'ticket_log_channel', 'ticket_support_role',
    'apply_channel', 'apply_log_channel'];
  for (const field of fields) {
    const input = form.querySelector(`[name="${field}"]`);
    if (input && config[field]) input.value = config[field];
  }

  form.addEventListener('submit', async (e) => {
    e.preventDefault();
    const data = {};
    for (const el of form.querySelectorAll('input[name]')) {
      data[el.name] = el.value;
    }
    const res = await fetch(`/api/guild/${guildId}/config`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify(data),
    });
    const json = await res.json();
    const msg = document.getElementById('saveMsg');
    if (json.success) {
      msg.textContent = '✅ კონფიგურაცია შენახულია!';
      msg.className = 'save-msg show-success';
    } else {
      msg.textContent = '❌ შეცდომა შენახვისას';
      msg.className = 'save-msg show-error';
    }
    setTimeout(() => { msg.textContent = ''; msg.className = 'save-msg'; }, 3000);
  });
}

function showTab(tab) {
  document.querySelectorAll('.tab-content').forEach(el => el.classList.remove('active'));
  document.querySelectorAll('.nav-item').forEach(el => el.classList.remove('active'));
  document.getElementById(`tab-${tab}`)?.classList.add('active');
  event.currentTarget?.classList.add('active');
}

init();
