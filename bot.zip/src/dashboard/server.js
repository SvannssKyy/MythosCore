require('dotenv').config({ path: require('path').join(__dirname, '../../.env') });
const express = require('express');
const session = require('express-session');
const passport = require('passport');
const DiscordStrategy = require('passport-discord').Strategy;
const path = require('path');
const axios = require('axios');
const { getGuildConfig, setGuildConfig, getGuildApplications, getGuildTickets, getAllActiveGiveaways, getTopInviters } = require('../database/Database');

const app = express();
const PORT = process.env.DASHBOARD_PORT || 3000;
const DASHBOARD_URL = process.env.DASHBOARD_URL || `http://localhost:${PORT}`;

app.use(express.json());
app.use(express.urlencoded({ extended: true }));
app.use(express.static(path.join(__dirname, 'public')));

app.use(session({
  secret: process.env.SESSION_SECRET || 'mythos-core-secret',
  resave: false,
  saveUninitialized: false,
  cookie: { maxAge: 7 * 24 * 60 * 60 * 1000 }
}));

app.use(passport.initialize());
app.use(passport.session());

passport.use(new DiscordStrategy({
  clientID: process.env.CLIENT_ID,
  clientSecret: process.env.CLIENT_SECRET,
  callbackURL: `${DASHBOARD_URL}/auth/callback`,
  scope: ['identify', 'guilds'],
}, (accessToken, refreshToken, profile, done) => {
  profile.accessToken = accessToken;
  return done(null, profile);
}));

passport.serializeUser((user, done) => done(null, user));
passport.deserializeUser((user, done) => done(null, user));

function isAuth(req, res, next) {
  if (req.isAuthenticated()) return next();
  res.redirect('/login');
}

// ─── Auth Routes ────────────────────────────────────────────────────────────
app.get('/login', passport.authenticate('discord'));
app.get('/auth/callback', passport.authenticate('discord', { failureRedirect: '/login' }),
  (req, res) => res.redirect('/dashboard')
);
app.get('/logout', (req, res) => {
  req.logout(() => res.redirect('/'));
});

// ─── Pages ──────────────────────────────────────────────────────────────────
app.get('/', (req, res) => res.sendFile(path.join(__dirname, 'public', 'index.html')));

app.get('/dashboard', isAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'dashboard.html'));
});

app.get('/dashboard/:guildId', isAuth, (req, res) => {
  res.sendFile(path.join(__dirname, 'public', 'guild.html'));
});

// ─── API ────────────────────────────────────────────────────────────────────
app.get('/api/user', isAuth, (req, res) => {
  res.json({
    id: req.user.id,
    username: req.user.username,
    discriminator: req.user.discriminator,
    avatar: req.user.avatar,
    guilds: req.user.guilds?.filter(g => (BigInt(g.permissions) & BigInt(0x20)) === BigInt(0x20)) || []
  });
});

app.get('/api/guilds', isAuth, async (req, res) => {
  try {
    const userGuilds = req.user.guilds?.filter(g =>
      (BigInt(g.permissions) & BigInt(0x20)) === BigInt(0x20)
    ) || [];
    res.json(userGuilds);
  } catch (err) {
    res.status(500).json({ error: 'შეცდომა' });
  }
});

app.get('/api/guild/:guildId/config', isAuth, (req, res) => {
  const config = getGuildConfig(req.params.guildId);
  res.json(config);
});

app.post('/api/guild/:guildId/config', isAuth, (req, res) => {
  const { guildId } = req.params;
  const allowed = ['join_channel', 'join_message', 'leave_channel', 'leave_message',
    'auto_role', 'ticket_category', 'ticket_log_channel', 'ticket_support_role',
    'apply_channel', 'apply_log_channel', 'giveaway_role'];

  for (const [key, value] of Object.entries(req.body)) {
    if (allowed.includes(key) && value !== undefined) {
      setGuildConfig(guildId, key, value || null);
    }
  }
  res.json({ success: true, message: 'კონფიგურაცია შენახულია!' });
});

app.get('/api/guild/:guildId/tickets', isAuth, (req, res) => {
  const tickets = getGuildTickets(req.params.guildId);
  res.json(tickets);
});

app.get('/api/guild/:guildId/applications', isAuth, (req, res) => {
  const apps = getGuildApplications(req.params.guildId);
  res.json(apps);
});

app.get('/api/guild/:guildId/giveaways', isAuth, (req, res) => {
  const giveaways = getAllActiveGiveaways(req.params.guildId);
  res.json(giveaways);
});

app.get('/api/guild/:guildId/invites', isAuth, (req, res) => {
  const top = getTopInviters(req.params.guildId, 20);
  res.json(top);
});

app.get('/api/stats', isAuth, (req, res) => {
  const { db } = require('../database/Database');
  const stats = {
    totalTickets: db.prepare('SELECT COUNT(*) as c FROM tickets').get().c,
    openTickets: db.prepare("SELECT COUNT(*) as c FROM tickets WHERE status = 'open'").get().c,
    totalApplications: db.prepare('SELECT COUNT(*) as c FROM applications').get().c,
    totalGiveaways: db.prepare('SELECT COUNT(*) as c FROM giveaways').get().c,
    activeGiveaways: db.prepare('SELECT COUNT(*) as c FROM giveaways WHERE ended = 0').get().c,
  };
  res.json(stats);
});

app.listen(PORT, () => {
  console.log(`\n🌐 დეშბორდი გაეშვა: ${DASHBOARD_URL}`);
});
